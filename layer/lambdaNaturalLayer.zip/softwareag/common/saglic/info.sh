#!/bin/sh
################################################################################
# Copyright (c) 2005-2016 Software AG, Darmstadt, Germany and/or Software AG USA
# Inc., Reston, VA, USA, and/or its subsidiaries and/or its affiliates
# and/or their licensors.
# Use, reproduction, transfer, publication or disclosure is prohibited except
# as specifically provided for in your License Agreement with Software AG.
#
#  $Id: info.sh 2650 2016-07-29 08:34:07Z bal $
################################################################################

saglicutil getcpucountinfo
saglicutil getbucketinfo

exit 0
